// var mysql = require("mysql");
// var Employee = {
// 	name: {type: String},
//   location: {type: String}
// }
